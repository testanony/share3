import copy
import json
from typing import List

import pandas as pd
import dgl
import copy
import torch
import torch.nn.functional as F


def min_max_normalize(normalize_dict: dict, G_list):
    nfeat_min = normalize_dict["nfeat_min"]
    nfeat_max = normalize_dict["nfeat_max"]
    efeat_min = normalize_dict["efeat_min"]
    efeat_max = normalize_dict["efeat_max"]

    # avoid dividing by zero
    nfeat_denominator = torch.add(torch.sub(nfeat_max, nfeat_min),
                                  torch.ones(nfeat_min.shape))
    efeat_denominator = torch.add(torch.sub(efeat_max, efeat_min),
                                  torch.ones(efeat_min.shape))

    G = dgl.batch(G_list)
    G.ndata['nfeat'] = torch.div(torch.sub(G.ndata['nfeat'], nfeat_min),
                                 nfeat_denominator)
    G.edata['efeat'] = torch.div(torch.sub(G.edata['efeat'], efeat_min),
                                 efeat_denominator)
    G_list = dgl.unbatch(G)
    return G_list


def load_file(file_name):
    json_list = []
    with open(file_name, 'r') as f:
        for line in f:
            d = json.loads(line)
            json_list.append(d)
    return json_list


def padding_feature_tensors(feature):
    padlen = 28
    gap = padlen - len(feature)
    if gap <= 0:
        return feature
    else:
        return feature + [0] * gap


def name_to_index(graph_dict):
    """
    create dict to change name to index, since the graph node should be integer
    """
    name_to_index_dict = dict()
    idx = 0
    for name in graph_dict:
        name_to_index_dict[name] = idx
        idx = idx + 1
    return name_to_index_dict


def build_node_features_list(graph_json: dict):
    # just get a list of node features from a single graph json
    feature_list = []
    for name in graph_json:
        feature_list.append(graph_json[name]["feature"])
    return feature_list


def build_multi_etype_edge_list_for_graph(graph_dict, name_to_index_dict,
                                          args):
    edge_list = []
    for key in graph_dict:
        for children in graph_dict[key]['children']:
            if "bwd" in children and "bwd" not in key:
                edge_list.append(
                    (name_to_index_dict[key], name_to_index_dict[children],
                     1))  # dependency
            else:
                edge_list.append((name_to_index_dict[key],
                                  name_to_index_dict[children], 0))  # dataflow

        # now mse, tensor node maybe deprecated
        if "mse" not in args.type and "use" in graph_dict[key]:
            for use in graph_dict[key]['use']:
                edge_list.append(
                    (name_to_index_dict[key], name_to_index_dict[use], 2))
        if "mse" not in args.type and "define" in graph_dict[key]:
            edge_list.append((name_to_index_dict[graph_dict[key]["define"]],
                              name_to_index_dict[key], 3))
    return edge_list


# raw features
# {0: 'layer_mem_total',
#  1: 'model_weight_mem',
#  2: 'model_weight_gradient',
#  3: 'layer_output_mem',
#  4: 'layer_max_ws_mem',
#  5: 'layer_output_diff_mem',
#  6: 'forward_FLOPs',
#  7: 'backward_FLOPs',
#  8: 'opeartor_index',
#  9: 'operator_type',
#  10: 'execution_rank',
#  11: 'device_FLOPs',
#  12: 'device_clock',
#  13: 'device_memory',
#  14: 'device_mem_bandwidth',
#  15: 'output_shape', x4
#  19: 'hyperparameter_embeddings'}

# Currently make these operator's hyperparameters as one-hot encoding
# e.g. 000-101-000-000 for CONV, 111-000-000 for POOLING
OP_TYPE_CONV = 2
OP_TYPE_POOL = 3
OP_TYPE_CONCAT = 6
OP_TYPE_DROPOUT = 7
OP_TYPE_UNKNOWN = 0
OP_TYPE_RNN = 11

def node_feature_rearrange(feature: list, task: str, forward, args):
    """
    Parameters
    ----------
    feature: a list of a single node feature
    task: mem task or time task
    forward: whether the node is in forward or backward propagation
    args: args initialized in the main function, used for feature extension

    Returns: a feature padding by zeros to 28 dims
    -------
    """
    new_feature = []
    if not args.edge_feature_enabled and not args.attention:
        # for test GCN only
        if feature[9] == OP_TYPE_CONV:
            new_feature.append(1)
        else:
            new_feature.append(0)
        if feature[9] == OP_TYPE_POOL:
            new_feature.append(1)
        else:
            new_feature.append(0)
        if feature[9] == OP_TYPE_CONCAT:
            new_feature.append(1)
        else:
            new_feature.append(0)

        if feature[9] == OP_TYPE_DROPOUT:
            new_feature.append(1)
        else:
            new_feature.append(0)
        if feature[9] == OP_TYPE_RNN:
            new_feature.append(1)
        else:
            new_feature.append(0)
        return padding_feature_tensors(new_feature)
    if args.only_tensor_feature:
        # new_feature.extend(feature[0:6])  # mem related feature
        new_feature.extend(feature[15:19])
        new_feature.extend([0, 0])
        fp_bp_flops_feat = [feature[6]
                            ] + [0] if forward else [0] + [feature[7]]
        new_feature.extend(fp_bp_flops_feat)
    else:
        new_feature.extend(feature[0:6])  # mem related feature

        # fp_bp_flops_feat
        if task == "time":
            if forward is None:
                fp_bp_flops_feat = [feature[6], feature[7]]
            else:
                fp_bp_flops_feat = [feature[6]
                                    ] + [0] if forward else [0] + [feature[7]]
            new_feature.extend(fp_bp_flops_feat)
            new_feature.append(feature[11])  # device flops
            new_feature.append(feature[12])  # device clock
            new_feature.append(feature[13])  # device memory
            new_feature.append(feature[14])  # device memory bandwidth

        else:
            # new_feature.extend(feature[15:19])
            if forward is None:
                fp_bp_flops_feat = [feature[6], feature[7]]
            else:
                fp_bp_flops_feat = [feature[6]
                                    ] + [0] if forward else [0] + [feature[7]]
            new_feature.extend(fp_bp_flops_feat)
            new_feature.append(feature[13])  # device memory
    if feature[9] == OP_TYPE_CONV:
        new_feature.extend(feature[19:23])  # filter
        new_feature.extend(feature[24:26])  # stride
    else:
        new_feature.extend([0, 0, 0, 0])

    if feature[9] == OP_TYPE_POOL:
        new_feature.extend(feature[19:23])
    else:
        new_feature.extend([0, 0, 0, 0])

    if feature[9] == OP_TYPE_CONCAT:
        new_feature.append(1)
    else:
        new_feature.append(0)

    if feature[9] == OP_TYPE_DROPOUT:
        new_feature.append(1)
    else:
        new_feature.append(0)
    if feature[9] == OP_TYPE_RNN:
        new_feature.append(1)
    else:
        new_feature.append(0)

    return padding_feature_tensors(new_feature)


def construct_dataflow_graph(args, dag_json):
    fp_layers_name_list = []
    fp_layer_sorted_list = []
    bp_layer_sorted_list = []
    fp_layers_dic = {}
    bp_layers_dic = {}

    layer_cost_list = dag_json

    def construct_backpropagation_graph(layer_cost_list):
        #  construct bp graph to get the fully computation graph
        for layer_cost_key in layer_cost_list:
            layer_cost = layer_cost_list[layer_cost_key]
            layer = {}
            layer["name"] = layer_cost_key  # layer_cost["name"]
            layer["parents"] = []
            layer["children"] = []
            layer["feature"] = copy.deepcopy(layer_cost["feature"])
            layer["feature"] = node_feature_rearrange(
                layer["feature"],
                task=args.type,
                forward=True,
                args=args,
            )

            fp_layers_name_list.append(layer_cost_key)

            for child in layer_cost["children"]:
                layer["children"].append(child)
            for parent in layer_cost["parents"]:
                layer["parents"].append(parent)

            fp_layer_sorted_list.append(layer)

            bp_layer = {}
            bp_layer[
                "name"] = layer_cost_key + "_bwd"  # layer_cost["name"] + "_bwd"
            bp_layer["parents"] = []
            bp_layer["children"] = []
            bp_layer["feature"] = node_feature_rearrange(copy.deepcopy(
                layer_cost["feature"]),
                                                         task=args.type,
                                                         forward=False,
                                                         args=args)

            for child in layer_cost["children"]:
                bp_layer["parents"].append(child + "_bwd")
            for parent in layer_cost["parents"]:
                bp_layer["children"].append(parent + "_bwd")

            bp_layer["parents"].append(layer["name"])
            layer["children"].append(bp_layer["name"])

            # layer = {layer_cost_key: layer}
            # bp_layer = {layer_cost_key + "_bwd" : layer}

            fp_layers_dic[layer["name"]] = layer
            bp_layers_dic[bp_layer["name"]] = bp_layer
            bp_layer_sorted_list.append(bp_layer)

        bp_layer_sorted_list.reverse()
        fp_bp_layer_sorted_list = fp_layer_sorted_list + bp_layer_sorted_list

        all_layer_dic = {}
        for item in fp_bp_layer_sorted_list:
            all_layer_dic[item["name"]] = item
        return all_layer_dic

    def rearrange_forward_graph(layer_cost_list):
        for layer_cost_key in layer_cost_list:
            layer_cost = layer_cost_list[layer_cost_key]
            layer = {}
            layer["name"] = layer_cost_key  # layer_cost["name"]
            layer["parents"] = []
            layer["children"] = []
            layer["feature"] = copy.deepcopy(layer_cost["feature"])
            layer["feature"] = node_feature_rearrange(
                layer["feature"],
                task=args.type,
                forward=None,
                args=args,
            )
            fp_layers_name_list.append(layer_cost_key)
            for child in layer_cost["children"]:
                layer["children"].append(child)
            for parent in layer_cost["parents"]:
                layer["parents"].append(parent)

            fp_layer_sorted_list.append(layer)
            fp_layers_dic[layer["name"]] = layer

        all_layer_dic = {}
        for item in fp_layer_sorted_list:
            all_layer_dic[item["name"]] = item
        return all_layer_dic

    # main extry of the function
    dataflow_graph = construct_backpropagation_graph(layer_cost_list)

    return dataflow_graph


def build_case_info_list(data_path, task, scale_up_factor: int):

    df = pd.read_csv("{}/DL_model_runtime_perf_labels.csv".format(data_path))
    # nas_test_0_64_448_5_5_P40_0_train
    # since device info can only get from name, so。。。
    raw_model_name_list: List[str] = df["per_single_model_name"].tolist()
    device_list = []
    model_name_list = []

    for model_name in raw_model_name_list:
        # TODO: Hard code for device
        device_list.append("p40")

        if "nas" in model_name:
            model_name_list.append(model_name.split('_')[0])
        else:
            model_name_list.append(model_name.split('-')[0])

    if task == "time":
        time_list = df["time"] * scale_up_factor
        return time_list.tolist(), device_list, model_name_list
    elif task == "mem":
        mem_list = df["mem_mb"] / (1024)  # convert to GB
        return mem_list.tolist(), device_list, model_name_list
    else:
        raise Exception("select task error!")


def build_gnn_graph_list(args):
    graph_dict_path = "{}/DL_model_runtime_perf_features.txt".format(args.path)
    graph_dict_list = load_file(graph_dict_path)
    dgl_graph_list = []
    for i in range(len(graph_dict_list)):
        g = dgl.DGLGraph()
        graph_json = construct_dataflow_graph(args, graph_dict_list[i])
        name_to_index_dict = name_to_index(graph_json)
        edge_list = build_multi_etype_edge_list_for_graph(
            graph_json, name_to_index_dict, args)
        num_node = len(name_to_index_dict)
        g.add_nodes(num_node)

        features_list = [graph_json[name]["feature"] for name in graph_json]
        features_tensor = torch.tensor(features_list)

        g.ndata['nfeat'] = features_tensor
        for u, v, etype in edge_list:
            efeat = torch.zeros(1, 8)
            efeat[0][
                etype] = 1  # one-hot, 0~3 used for type specifying, now deprecated(only 2 type)
            # [Dataflow, (Dependency), Use, Define]
            if etype == 0:
                efeat[0][3] = features_list[u][3]  # "layer_output_mem"
            elif etype == 1:
                efeat[0][4] = features_list[u][1]  # "weight size"
            efeat[0][5] = features_list[u][11]  # "device mem bandwidth"

            g.add_edge(u, v, {
                'efeat': efeat,
                'etype': torch.tensor(etype).view((1, 1))
            })

        dgl_graph_list.append(g)

    return dgl_graph_list, graph_dict_list
