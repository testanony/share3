from dgl.nn.pytorch import GraphConv, GATConv
import torch.nn as nn
import torch.nn.functional as F
import dgl.function as fn
import torch
import dgl


class GAT(nn.Module):
    def __init__(self, args):
        super(GAT, self).__init__()
        layers = []
        self.in_dim = args.in_dim
        self.out_dim = args.out_dim
        self.hidden_dim = args.hidden_dim
        self.num_of_rounds = args.msg_rounds
        self.attention = args.attention
        self.device = torch.device(
            'cuda' if torch.cuda.is_available() else 'cpu')
        if self.attention:
            # GAT
            NUM_OF_HEAD = 1
            layers.append(GATConv(self.in_dim, self.hidden_dim, NUM_OF_HEAD))
            for i in range(self.num_of_rounds):
                layers.append(
                    GATConv(self.hidden_dim, self.hidden_dim, NUM_OF_HEAD))
            self.layers = nn.ModuleList(layers)
        else:
            # just GCN
            layers.append(GraphConv(self.in_dim, self.hidden_dim))
            for i in range(self.num_of_rounds):
                layers.append(GraphConv(self.hidden_dim, self.hidden_dim))
            self.layers = nn.ModuleList(layers)
        self.linear_input_size = self.hidden_dim
        self.predict = nn.Linear(self.linear_input_size, 512)
        self.predict2 = nn.Linear(512, 128)
        self.predict3 = nn.Linear(128, 16)
        self.predict4 = nn.Linear(16, 1)

    def forward(self, g):
        h = g.ndata['nfeat']

        for layer in self.layers:
            h = F.relu(layer(g, h))
        g.ndata['h'] = h

        hg = F.relu(dgl.sum_nodes(g, 'h'))

        # change the shape (bz, 1, hidden) to (bz, hidden)
        hg = hg.reshape(len(hg), self.hidden_dim)

        hg = F.leaky_relu(self.predict(hg))
        hg = F.leaky_relu(self.predict2(hg))
        hg = F.leaky_relu(self.predict3(hg))
        hg = F.leaky_relu(self.predict4(hg))
        return hg

class ANEELayer(nn.Module):
    def __init__(self, in_dim, out_dim, efeat_dim, efeat_out_dim):
        super(ANEELayer, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.efeat_dim = efeat_dim

        # use two fully-connected layers to learn node representation
        self.node_fc = nn.Linear(in_dim, out_dim, bias=False)
        self.node_fc2 = nn.Linear(out_dim, out_dim, bias=False)
        # maps the concatenated edge's neighbors node feature to a scalar value, used in edge function
        self.attn_w = nn.Linear(out_dim * 2, 1, bias=False)
        # used in edge function to learn edge encoding
        self.efeat2efeat = nn.Linear(efeat_dim, efeat_dim, bias=False)
        # used in the reduce function to produce attention
        self.efeat2scalar = nn.Linear(efeat_out_dim, 1, bias=False)
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_normal_(self.node_fc.weight)
        nn.init.xavier_normal_(self.node_fc2.weight)
        nn.init.xavier_normal_(self.attn_w.weight)
        nn.init.xavier_normal_(self.efeat2efeat.weight)
        nn.init.xavier_normal_(self.efeat2scalar.weight)

    def node_function(self, nodes):
        nfeat = F.leaky_relu(self.node_fc(nodes.data['nfeat']))
        nfeat = F.leaky_relu(self.node_fc2(nfeat))
        return {'nfeat': nfeat}

    def edge_function(self, edges):
        cat = torch.cat([edges.src['nfeat'], edges.dst['nfeat']], dim=1)

        scalar = self.attn_w(cat)

        efeat = torch.mul(scalar, edges.data['efeat'])

        efeat = torch.sigmoid(self.efeat2efeat(efeat))

        return {'efeat': efeat}  # efeat won't be zero

    def message_function(self, edges):
        return {'efeat': edges.data['efeat'], 'nfeat': edges.src['nfeat']}

    def reduce_function(self, nodes):
        scalar = self.efeat2scalar(nodes.mailbox['efeat'])

        alpha = F.softmax(scalar, dim=1)

        h = F.leaky_relu(
            torch.sum(torch.mul(alpha, nodes.mailbox['nfeat']), dim=1))

        return {'nfeat': h}

    def forward(self, g):
        g.apply_nodes(self.node_function)
        g.apply_edges(self.edge_function)
        g.update_all(self.message_function, self.reduce_function)
        return


class ANEE(nn.Module):
    def __init__(self, args):
        super(ANEE, self).__init__()
        self.in_dim = args.in_dim
        self.out_dim = args.out_dim
        self.hidden_dim = args.hidden_dim
        self.efeat_dim = args.efeat_dim
        self.num_of_rounds = args.msg_rounds
        self.concat_edge = args.concat_edge
        self.avg_readout = args.avg_readout
        self.device = torch.device(
            'cuda' if torch.cuda.is_available() else 'cpu')
        self.rnn = nn.RNN(input_size=self.hidden_dim, hidden_size=512, num_layers=2) # this is for test only, deprecated
        layers = [
            ANEELayer(self.in_dim, self.hidden_dim, self.efeat_dim,
                      self.efeat_dim)
        ]

        for i in range(self.num_of_rounds):
            layers.append(
                ANEELayer(self.hidden_dim, self.hidden_dim, self.efeat_dim,
                          self.efeat_dim))
        self.layers = nn.ModuleList(layers)

        if args.concat_edge:
            self.linear_input_size = self.hidden_dim + self.efeat_dim
        else:
            self.linear_input_size = self.hidden_dim

        if "MLP" in args.model_name:
            self.linear_input_size = self.in_dim
            self.layers = nn.ModuleList([])

        self.predict = nn.Linear(self.linear_input_size, 512)
        self.predict2 = nn.Linear(512, 128)
        self.predict3 = nn.Linear(128, 16)
        self.predict4 = nn.Linear(16, 1)

        self.reset_parameters()

    def reset_parameters(self):
        gain = nn.init.calculate_gain('relu')
        nn.init.xavier_normal_(self.predict.weight, gain=gain)
        nn.init.xavier_normal_(self.predict2.weight, gain=gain)
        nn.init.xavier_normal_(self.predict3.weight, gain=gain)
        nn.init.xavier_normal_(self.predict4.weight, gain=gain)

    def forward(self, g: dgl.DGLGraph):
        with g.local_scope():
            for layer in self.layers:
                layer(g)

            # now the shape will be [batch_size, 1, feature_dim]

            if not self.avg_readout:
                hg = F.leaky_relu(dgl.sum_nodes(g, 'nfeat'))
            else:
                hg = F.leaky_relu(dgl.mean_nodes(g, 'nfeat'))

            if self.concat_edge:
                eg = F.leaky_relu(dgl.sum_edges(g, 'efeat'))
                hg = torch.cat([hg, eg], dim=1)


            hg = hg.reshape(len(hg), self.linear_input_size)
            hg = F.leaky_relu(self.predict(hg))
            hg = F.leaky_relu(self.predict2(hg))
            hg = F.leaky_relu(self.predict3(hg))
            hg = F.leaky_relu(self.predict4(hg))

            return hg
