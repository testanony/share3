cd ..
LOG_DIR="./log"

GPU_ID=0

DATASET_DIR="./Data/nas_hpo_seen"
BASIC_CONFIG="--path=${DATASET_DIR} --load_previous=0 --epoch=250 --type=mem --scale_up_labels=1 -lr=1e-4 -hd=2048 --batch_size=64 -s=1 --msg_rounds=1"
echo ${DATASET_DIR}
echo ${BASIC_CONFIG}


MODEL_NAME="MEM1_GAT"
LOG_NAME="mem_gnn1_gat.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --edge_feature_enabled=0 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="MEM1_GCN"
LOG_NAME="mem_gnn1_gcn.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --edge_feature_enabled=0 --attention=0 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="MEM1_OTF"
LOG_NAME="mem_gnn1_otf.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --only_tensor_feature=1 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="MEM1_ARO"
LOG_NAME="mem_gnn1_aro.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --avg_readout=1 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="MEM1_IEF"
LOG_NAME="mem_gnn1_ief.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --concat_edge=1 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

