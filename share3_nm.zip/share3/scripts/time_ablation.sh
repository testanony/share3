cd ..
LOG_DIR="./log"

GPU_ID=0

DATASET_DIR="./Data/nas_hpo_seen"
BASIC_CONFIG="--path=${DATASET_DIR} --load_previous=0 --epoch=200 --type=time --scale_up_labels=0.1 -lr=1e-4 -hd=1024 --batch_size=64 -s=1 --msg_rounds=3"
echo ${DATASET_DIR}
echo ${BASIC_CONFIG}


MODEL_NAME="TIME3_GAT"
LOG_NAME="time_gnn3_gat.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --edge_feature_enabled=0 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="TIME3_GCN"
LOG_NAME="time_gnn3_gcn.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --edge_feature_enabled=0 --attention=0 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="TIME3_ARO"
LOG_NAME="time_gnn3_aro.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --avg_readout=1 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="TIME3_OTF"
LOG_NAME="time_gnn3_otf.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --only_tensor_feature=1  --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1

MODEL_NAME="TIME3_IEF"
LOG_NAME="time_gnn3_ief.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --concat_edge=1 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1
