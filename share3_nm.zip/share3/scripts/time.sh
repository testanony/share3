cd ..
LOG_DIR="./log"

GPU_ID=0

DATASET_DIR="./Data/nas_hpo_seen"
BASIC_CONFIG="--path=${DATASET_DIR} --load_previous=0 --epoch=200 --type=time --scale_up_labels=0.1 -lr=1e-4 -hd=1024 --batch_size=64 -s=1 --msg_rounds=3"
MODEL_NAME="GNN_TIME"
LOG_NAME="gnn_time.log"

echo ${DATASET_DIR}
echo ${BASIC_CONFIG}
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1
