## Evaluation Scripts Doc for DNNPerf

### Memory Prediction

[Mem script is here(together with GNN iteration study)](../scripts/mem.sh)

|Model Name| Metrics | DNNPerf | BiRNN | ARNN | MLP | GBDT | BRP-NAS |
|----------| ------- | ------- | ----- | ---- | --- | ---- | ------- |
|Overall  | RMSE | 1.806 | 2.817 | 2.882 | 2.335 | 2.213 | 4.144 |
|Overall  | MRE | 13.684 | 22.302 | 25.497 | 21.460 | 15.592 | 33.654 |
|NAS     | RMSE | 1.820 | 2.811 | 2.369 | 1.955 | 2.437 | 3.991 |
|NAS      | MRE | 15.338 | 22.823 | 21.732 | 19.416 | 20.164 | 40.452 |
|ResNet-V1  | RMSE | 1.632 | 2.852 | 2.957 | 1.693 | 1.735 | 4.790 |
|ResNet-V1  | MRE | 8.716 | 15.342 | 16.254 | 9.727 | 7.378 | 31.064 |
|Inception-V3 | RMSE | 1.150 | 1.912 | 1.916 | 1.429 | 1.217 | 2.686 |
|Inception-V3  | MRE | 14.827 | 25.750 | 27.437 | 17.464 | 27.844 | 57.183 |
|LeNet  | RMSE | 1.313 | 2.557 | 2.236 | 1.561 | 1.587 | 3.466 |
|LeNet  | MRE | 11.401 | 19.913 | 20.081 | 15.799 | 15.103 | 46.489 |
|RNN  | RMSE | 0.813 | 1.055 | 1.451 | 0.940 | 0.861 | 4.735 |
|RNN  | MRE | 10.787 | 16.848 | 22.195 | 17.098 | 16.659 | 114.484 |
|LSTM  | RMSE | 2.105 | 4.225 | 5.487 | 2.847 | 1.336 | 6.503 |
|LSTM  | MRE | 14.678 | 36.017 | 54.649 | 24.913 | 7.867 | 46.936 |
|OverFeat(UNSEEN)  | RMSE | 1.188 | 2.469 | 2.980 | 2.941 | 1.320 | 1.131 |
|OverFeat  | MRE | 13.597 | 28.719 | 35.111 | 34.502 | 13.986 | 13.625 |
|VGG(UNSEEN)  | RMSE | 2.341 | 3.234 | 2.579 | 2.378 | 2.989 | 4.634 |
|VGG(UNSEEN)  | MRE | 15.772 | 17.918 | 17.897 | 16.786 | 16.499 | 28.979 |
|ResNet-V2(UNSEEN)  | RMSE | 1.640 | 2.755 | 2.851 | 1.684 | 1.784 | 4.683 |
|ResNet-V2(UNSEEN)  | MRE | 8.282 | 14.294 | 15.110 | 9.553 | 8.382 | 30.159 |
|AlexNet-V2(UNSEEN) | RMSE | 1.270 | 2.584 | 3.462 | 3.162 | 1.489 | 0.942 |
|AlexNet-V2(UNSEEN)  | MRE | 13.453 | 30.288 | 42.645 | 38.239 | 16.214 | 11.158 |
|GRU(UNSEEN) | RMSE | 2.273 | 2.991 | 2.973 | 2.418 | 2.835 | 5.490 |
|GRU(UNSEEN)  | MRE | 13.765 | 17.964 | 20.063 | 17.813 | 12.053 | 30.349 |

### Time Prediction

[Time Script is here(together with GNN iteration study)](../scripts/time.sh)

|Model Name| Metrics | DNNPerf | BiRNN | ARNN | MLP | GBDT | BRP-NAS |
|----------| ------- | ------- | ----- | ---- | --- | ---- | ------- |
|Overall  | RMSE | 58.5 | 151.4 | 113.9 | 106.2 | 122.6 | 335.4 |
|Overall  | MRE | 7.443 | 20.806 | 20.940 | 17.982 | 31.013 | 95.248 |
|NAS     | RMSE | 75.7 | 242.6 | 159.5 | 136.4 | 129.3 | 441.0 |
|NAS      | MRE | 6.272 | 18.418 | 16.879 | 13.471 | 24.353 | 122.304 |
|ResNet-V1  | RMSE | 60.0 | 84.2 | 109.3 | 74.5 | 130.5 | 505.3 |
|ResNet-V1  | MRE | 4.110 | 7.521 | 11.403 | 7.402 | 8.253 | 61.706 |
|Inception-V3 | RMSE | 41.2 | 58.3 | 70.1 | 31.3 | 53.6 | 175.2 |
|Inception-V3  | MRE | 12.697 | 28.680 | 41.854 | 18.464 | 47.683 | 95.833 |
|LeNet  | RMSE | 7.1 | 64.5 | 32.7 | 23.2 | 44.6 | 87.0 |
|LeNet  | MRE | 3.857 | 27.214 | 15.457 | 14.622 | 43.499 | 69.194 |
|RNN  | RMSE | 20.8 | 91.4 | 91.4 | 77.0 | 36.8 | 154.6 |
|RNN  | MRE | 8.491 | 41.321 | 40.958 | 36.038 | 21.123 | 77.296 |
|LSTM  | RMSE | 38.5 | 126.9 | 131.4 | 117.4 | 37.9 | 183.7 |
|LSTM  | MRE | 7.528 | 27.689 | 29.437 | 26.196 | 7.835 | 29.946 |
|OverFeat(UNSEEN)  | RMSE | 24.3 | 90.7 | 77.9 | 77.6 | 178.6 | 154.4 |
|OverFeat  | MRE | 7.462 | 20.735 | 24.892 | 16.211 | 58.530 | 65.409 |
|VGG(UNSEEN)  | RMSE | 84.2 | 164.6 | 92.3 | 154.4 | 148.6 | 339.0 |
|VGG(UNSEEN)  | MRE | 7.295 | 13.308 | 10.099 | 16.817 | 12.593 | 41.648 |
|ResNet-V2(UNSEEN)  | RMSE | 91.1 | 98.1 | 118.1 | 65.9 | 175.2 | 584.0 |
|ResNet-V2(UNSEEN)  | MRE | 5.690 | 7.232 | 10.580 | 5.892 | 9.933 | 65.009 |
|AlexNet-V2(UNSEEN) | RMSE | 13.6 | 27.1 | 28.6 | 26.5 | 90.4 | 264.6 |
|AlexNet-V2(UNSEEN)  | MRE | 11.942 | 22.545 | 18.394 | 21.633 | 85.414 | 291.101 |
|GRU(UNSEEN) | RMSE | 29.7 | 118.7 | 118.9 | 105.8 | 59.1 | 130.7 |
|GRU(UNSEEN)  | MRE | 6.334 | 28.187 | 28.714 | 26.042 | 15.154 | 29.344 |

### Stability Study

Performance of edge and node count in different range

Results are automatically generated when running above scripts

### Ablation study

[Mem Ablation Script is here](../scripts/mem_ablation.sh)

[Time Ablation Script is here](../scripts/time_ablation.sh)

