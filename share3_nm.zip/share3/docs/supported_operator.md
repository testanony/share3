The DNNPerf front-end parser supports a list of operators:

```
conv = ["conv2d", "decon2d"]
pool = ["pool", "averagepool", "maxpool"]
flatten =  ["flatten"]
dropout = ["dropout"]
data = ["input"]
concat = ["concatenate"]
shape = ["squeeze", "transpose", "reshape", 'unsqueeze']
# 27 ops
activation = ["elu", "hardshrink", "hardtanh", "leakyrelu", "logsigmoid", \
    "multiheadattention", "prelu", "relu", "relu6", "rrelu", "selu", "celu", \
    "gelu", "sigmoid", "softplus", "softshrink", "softsign", "tanh", \
    "tanhshrink", "threshold", "softmin", "softmax", "softmax2d", "logsoftmax",\
    "adaptivelogsoftmaxwithloss"]
# 53 ops
elementwise = ["abs", "acos", "add", "addcdiv", "addcmul", "angle", "asin", \
    "atan", "atan2", "bitwise_not", "bitwise_xor", "ceil", "clamp", "conj", \
    "cos", "cosh", "div", "digamma", "erf", "erfc", "erfinv", "exp", "expm1", \
    "floor", "fmod", "frac", "imag", "lerp", "lgamma", "log", "log10", "log1p" \
    "log2", "logical_not", "logical_xor", "mul", "mvlgamma", "neg", "polygamma"\
    "pow", "real", "reciprocal", "remainder", "round", "rsqrt", "sigmoid", \
    "sign", "sin", "sinh", "sqrt", "tan", "tanh", "trunc"]
rnn = ["rnn", "lstm", "gru"]
```


