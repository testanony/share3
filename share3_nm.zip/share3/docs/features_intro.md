# DNNPerf features introduction

#### **DL_model_runtime_perf_labels.csv**

 contains the following items:

+ bz: batch_size for generating data
+ in_shape: width and height for input data
+ channel: channel for input data
    + i.e. input data is shaped as W * H * C
+ mem_mb: memory label (mega byte)
+ time: time label (ms)
+ per_single_model_name: model name used for specifying what kind of nets


#### **DL_model_runtime_perf_features.txt** 

contains node-level features, and each dimension represents following information: 

+ operator_type
+ hyperparameter_embeddings
+ model_weight_mem
+ model_weight_gradient
+ layer_output_mem
+ layer_max_ws_mem
+ layer_output_diff_mem
+ output_shape
+ layer_mem_total
+ forward_FLOPs
+ backward_FLOPs
+ opeartor_index
+ execution_rank
+ device_FLOPs
+ device_clock
+ device_memory
+ device_mem_bandwidth

where these features are selected and rearranged in `node_feature_rearrange` function
