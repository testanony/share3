import argparse
import random
from train_def import model_train, model_eval
import numpy as np
import dgl
import torch
from data_utils.dataloader import get_gnn_exp_dataset, get_scaler_from_trainset, scaler_transform_dataset
from data_utils.testset_splitter import split_test_set

parser = argparse.ArgumentParser()
parser.add_argument('-p', '--path', type=str, metavar='N', help='Specify path')
parser.add_argument('-s', '--split', type=int, metavar='N', default=1)
parser.add_argument('-mn',
                    '--model_name',
                    type=str,
                    metavar='N',
                    default="None")
parser.add_argument('-vb',
                    '--verbose',
                    type=int,
                    metavar='N',
                    default=0)
# Training-related
parser.add_argument('-bz',
                    '--batch_size',
                    type=int,
                    metavar='N',
                    default=64,
                    help='Specify batch size')
parser.add_argument('-ep',
                    '--epoch',
                    type=int,
                    metavar='N',
                    default=200,
                    help='Specify epoch')
parser.add_argument('-t',
                    '--type',
                    type=str,
                    metavar='N',
                    default="time",
                    help="predicting time or mem")
parser.add_argument('-lr',
                    '--learning_rate',
                    type=float,
                    metavar='N',
                    default=1e-4)
parser.add_argument('-dc',
                    '--decay_rate',
                    type=float,
                    metavar='N',
                    default=0.999)
parser.add_argument('-mr',
                    '--msg_rounds',
                    type=int,
                    metavar='N',
                    default=2,
                    help='Specify msg_rounds')
parser.add_argument('-sul',
                    '--scale_up_labels',
                    type=float,
                    metavar='N',
                    default=1,
                    help='whether to multiply label by 100 (useful for time prediction)')

# Feature-related
parser.add_argument('-a',
                    '--attention',
                    type=int,
                    metavar='N',
                    default=1,
                    help='Specify attention')
parser.add_argument('-otf',
                    '--only_tensor_feature',
                    type=int,
                    metavar='N',
                    default=0,
                    help='Specify df feature')
parser.add_argument('-efe',
                    '--edge_feature_enabled',
                    type=int,
                    metavar='N',
                    default=1)

# Model-related
parser.add_argument('-ce', '--concat_edge', type=int, metavar='N', default=0)
parser.add_argument('-avo', '--avg_readout', type=int, metavar='N', default=0)   # default is sum readout


parser.add_argument('-id',
                    '--in_dim',
                    type=int,
                    metavar='N',
                    default=28,
                    help='Specify node feature sizes')
parser.add_argument('-hd',
                    '--hidden_dim',
                    type=int,
                    metavar='N',
                    default=1024,
                    help='Specify hidden layer sizes')
parser.add_argument('-od',
                    '--out_dim',
                    type=int,
                    metavar='N',
                    default=1,
                    help='Specify output features')
parser.add_argument('-ed', '--efeat_dim', type=int, metavar='N', default=8)

# Validating/experiment-related
parser.add_argument('-scl',
                    '--scaler',
                    type=str,
                    metavar='N',
                    default="MinMax")
parser.add_argument('-tsr',
                    '--trainset_sampling_ratio',
                    type=float,
                    metavar='N',
                    default=1.0)
parser.add_argument('-dt',
                    '--deterministic',
                    type=int,
                    metavar='N',
                    default=1,
                    help="whether set up seed")
parser.add_argument('-lp',
                    '--load_previous',
                    type=int,
                    metavar='N',
                    default=0,
                    help='load previous model to avoid duplicate training')


def setup_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    dgl.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True

def get_normalized_train_test_set(trainset, validset, testset, args):
    n_scaler, e_scaler = get_scaler_from_trainset(trainset, args)
    trainset = scaler_transform_dataset(trainset, n_scaler, e_scaler)
    validset = scaler_transform_dataset(validset, n_scaler, e_scaler)
    if args.split:
        testset_dict = split_test_set(testset, n_scaler, e_scaler, args)
    else:
        testset_dict = {"all": scaler_transform_dataset(testset, n_scaler, e_scaler)}
    return trainset, validset, testset_dict


def duplicate_some_data(trainset):
    target = ["resnet", "inception"]
    dup_trainset = []
    for item in trainset:
        if "inception" in item[-1]:
            dup_trainset.append(item)
            dup_trainset.append(item)
        else:
            dup_trainset.append(item)
    return dup_trainset


def get_dataset(args):
    dataset = get_gnn_exp_dataset(args)

    random.shuffle(dataset)
    random.shuffle(dataset)
    random.shuffle(dataset)

    trainset = dataset[int(len(dataset) * 0.3):-1]  # 7
    trainset = trainset[:int(
        len(trainset) *
        args.trainset_sampling_ratio)]  # select certain samples by ratio

    print("len of trainset: ", len(trainset))
    # trainset = duplicate_some_data(trainset)
    testset = dataset[int(len(dataset) * 0.1):int(len(dataset) * 0.3)]  # 2
    validset = dataset[0:int(len(dataset) * 0.1)]  # 1

    trainset, validset, testset_dict = get_normalized_train_test_set(
        trainset, validset, testset, args)
    return trainset, validset, testset_dict


if __name__ == '__main__':
    args = parser.parse_args()
    path = args.path

    print("training task: ", args.type)
    print("deterministic: ", args.deterministic)
    print("trainset_sampling_ratio: ", args.trainset_sampling_ratio)
    print("edge_feature_enabled: ", args.edge_feature_enabled)
    print("concat edge: ", args.concat_edge)
    print("only_tensor_feature", args.only_tensor_feature)
    print("msg_rounds: ", args.msg_rounds)
    print("lr: ", args.learning_rate)
    print("bz: ", args.batch_size)
    print("decay: ", args.decay_rate)
    print("scale_up_labels: ", args.scale_up_labels)
    print("split: ", args.split)
    print("scaler: ", args.scaler)


    # since in model_def.py, a default layer is already placed
    args.msg_rounds = args.msg_rounds - 1

    # if args.deterministic:
    setup_seed(21)

    trainset, validset, testset_dict = get_dataset(args)

    model = model_train(args, trainset, validset, testset_dict)

    model_eval(args, model, testset_dict)