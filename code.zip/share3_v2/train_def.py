from model_def import GAT, ANEE
from torch.utils.data import DataLoader
from sklearn.metrics import mean_squared_error, mean_absolute_error
import torch
import dgl
import torch.optim as optim
import torch.nn as nn
import time
import sys
import numpy as np
import math

RED = "\033[1;31m"
BLUE = "\033[1;34m"
CYAN = "\033[1;36m"
GREEN = "\033[0;32m"
RESET = "\033[0;0m"
BOLD = "\033[;1m"
REVERSE = "\033[;7m"

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


def get_model_name(args, epoch):
    if args.model_name == "None":
        model_name = "efe{}_tsr{}_type{}_bz{}_mr{}_hd{}_sul{}_epoch{}".format(
            args.edge_feature_enabled, args.trainset_sampling_ratio, args.type,
            args.batch_size, args.msg_rounds, args.hidden_dim,
            args.scale_up_labels, epoch)
        print("Default model name: ", model_name)
    else:
        model_name = args.model_name + "_{}".format(epoch)
        print("Custom model name: ", model_name)
    return model_name


def collate(samples):
    # The input `samples` is a list of pairs
    #  (graph, label).
    graphs, labels, origin_features, device_list, model_name_list = map(
        list, zip(*samples))
    batched_graph = dgl.batch(graphs)
    return batched_graph, torch.tensor(labels)


def save_model(model, epoch, args):
    model_name = get_model_name(args, epoch)
    if args.load_previous == 0:
        import os
        if not os.path.exists("./models"):
            os.mkdir("./models")
        # model_name = "efe{}_tsr{}_type{}_bz{}_mr{}_hd{}_sul{}"
        if not os.path.exists("./models/{}".format(model_name)):
            os.mkdir("./models/{}".format(model_name))

        checkpoint_dir = "./models/{}/graphnn_for_dl_{}_{}.model".format(
            model_name, args.batch_size, args.msg_rounds)
        torch.save(model.state_dict(), checkpoint_dir)
        if args.edge_feature_enabled:
            model = ANEE(args).to(device)
        else:
            model = GAT(args).to(device)
        model.load_state_dict(torch.load(checkpoint_dir))


def model_train(args, trainset, validset, testset_dict):
    # Use PyTorch's DataLoader and the collate function
    # defined before.
    batch_size = args.batch_size
    epochs_num = args.epoch

    train_loader = DataLoader(trainset,
                              batch_size=batch_size,
                              shuffle=(not args.deterministic),
                              collate_fn=collate,
                              drop_last=True)
    valid_loader = DataLoader(validset,
                              batch_size=batch_size,
                              shuffle=False,
                              collate_fn=collate,
                              drop_last=True)

    if args.load_previous == 0:
        if args.edge_feature_enabled:
            model = ANEE(args)
        else:
            model = GAT(args)
    else:
        model_name = args.model_name
        checkpoint_dir = "./models/{}/graphnn_for_dl_{}_{}.model".format(
            model_name, args.batch_size, args.msg_rounds)
        print("Load previous from: ", checkpoint_dir)
        if args.edge_feature_enabled:
            model = ANEE(args)
        else:
            model = GAT(args)
        model.load_state_dict(torch.load(checkpoint_dir))

    model.to(device)

    loss_func = nn.MSELoss().to(device)
    optimizer = optim.Adam(model.parameters(),
                           lr=args.learning_rate,
                           weight_decay=1e-4)
    my_lr_scheduler = torch.optim.lr_scheduler.ExponentialLR(
        optimizer=optimizer, gamma=args.decay_rate)

    epoch_losses = []
    for epoch in range(1, epochs_num + 1):
        model.train()
        start = time.time()
        epoch_loss = 0
        sample_count = 0
        accuracy_list = []
        for iter, (bg, label) in enumerate(train_loader):
            sample_count += 1
            bg.to(device)
            prediction = model(bg)
            loss = loss_func(prediction.reshape(batch_size, 1),
                             label.reshape(batch_size, 1).to(device))
            accuracy_list.append(1 - np.mean(
                abs((np.array(
                    prediction.reshape(batch_size, 1).cpu().detach().numpy()) -
                     np.array(
                         label.reshape(batch_size, 1).cpu().detach().numpy()))
                    / np.array(
                    label.reshape(batch_size, 1).cpu().detach().numpy()))))

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            epoch_loss += loss.detach().item()
        my_lr_scheduler.step()
        epoch_loss /= (iter + 1)
        print('Epoch {}, loss {}'.format(epoch, epoch_loss))
        print("Accuracy: {}".format(np.mean(np.array(accuracy_list))))
        epoch_losses.append(epoch_loss)
        end = time.time()
        exec_time = end - start
        sample_per_second = sample_count / exec_time * batch_size
        print("[sys perf metrics] training graphs / seconds {}".format(
            sample_per_second))

        model.eval()
        if epoch % 10 == 0:
            sample_count = 0
            start = time.time()
            with torch.no_grad():
                predict_list = []
                label_list = []
                for iter, (bg, label) in enumerate(valid_loader):
                    sample_count += 1
                    bg.to(device)
                    prediction = model(bg)
                    predict_list.extend(prediction.cpu().detach().reshape(
                        batch_size, 1).numpy())
                    label_list.extend(label.cpu().detach().reshape(
                        batch_size, 1).numpy())
                sys.stdout.write(RED)
                print("VALIDATION")
                print("ERR: {}".format(
                    np.mean(
                        abs(np.array(label_list) - np.array(predict_list)) /
                        np.array(label_list)) * 100))
                sys.stdout.write(RESET)
                end = time.time()
                exec_time = end - start
                sample_per_second = sample_count / exec_time * batch_size
                print(
                    "[sys perf metrics] infering graphs / seconds {}\n".format(
                        sample_per_second))

        if args.load_previous == 0 and epoch % 50 == 0:
            # loading model is not saved by default
            save_model(model, epoch, args)


    return model


def model_eval(args, model, testset_dict):
    model.eval()

    for testset_name in testset_dict:
        testset = testset_dict[testset_name]
        with torch.no_grad():
            sys.stdout.write(GREEN)
            print("Testset: {}, length: {}".format(testset_name, len(testset)))
            test_loader_bz = 1
            test_loader = DataLoader(testset,
                                     batch_size=test_loader_bz,
                                     shuffle=False,
                                     collate_fn=collate,
                                     drop_last=True)

            predict_list = []
            label_list = []
            for iter, (bg, label) in enumerate(test_loader):
                bg.to(device)
                prediction = model(bg)
                predict_list.extend(prediction.cpu().detach().reshape(
                    test_loader_bz, 1).numpy())
                label_list.extend(label.cpu().detach().reshape(test_loader_bz, 1).numpy())

            sys.stdout.write(RESET)
            print("TESTING")

            # print(len(label_list))

            # predict_list = np.add(predict_list, 8)

            mse = mean_squared_error(label_list,
                                     predict_list) / (args.scale_up_labels ** 2)
            mae = mean_absolute_error(label_list,
                                      predict_list) / (args.scale_up_labels)
            error_rate = np.mean(
                abs(np.array(label_list) - np.array(predict_list)) /
                np.array(label_list)) * 100

            print("MSE: {}".format(mse))
            print("ERR: {}".format(error_rate))
            print("MAE: {}".format(mae))
            print("RMSE: {}".format(math.sqrt(mse)))
