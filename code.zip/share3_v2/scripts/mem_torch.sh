cd ..
LOG_DIR="./log"

GPU_ID=0

DATASET_DIR="./Data/torch_hpo_data"
BASIC_CONFIG="--path=${DATASET_DIR} --load_previous=1 --epoch=0 --type=mem --scale_up_labels=1 -lr=1e-2 -hd=2048 --batch_size=64 -s=1 -bn=1 -ehif=1 -pt=1"
echo ${DATASET_DIR}
echo ${BASIC_CONFIG}

MODEL_NAME="TORCH_MEM"
LOG_NAME="torch_mem.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --msg_rounds=2 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1
