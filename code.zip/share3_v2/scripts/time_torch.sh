cd ..
LOG_DIR="./log"

GPU_ID=1

DATASET_DIR="./Data/torch_hpo_data"

BASIC_CONFIG="--path=${DATASET_DIR} --load_previous=1 --epoch=0 --type=time --scale_up_labels=1000 -lr=1e-2 -hd=1024 --batch_size=64 -s=1 -bn=1 -ehif=1 -pt=1"
echo ${DATASET_DIR}
echo ${BASIC_CONFIG}

MODEL_NAME="TORCH_TIME"
LOG_NAME="torch_time.log"
echo ${MODEL_NAME}
CUDA_VISIBLE_DEVICES=${GPU_ID} python -u dnnperf.py ${BASIC_CONFIG} --msg_rounds=2 --model_name=${MODEL_NAME} > ${LOG_DIR}/${LOG_NAME} 2>&1
