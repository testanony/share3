# DNNPerf

## Prerequisites
+ Python 3.7.x (tested with Python 3.7.7)
+ PyTorch>=1.4.0 (tested with PyTorch 1.5.0, py3.7_cuda10.2.89_cudnn7.6.5_0 version)
+ dgl (tested with dgl-cuda10.2=0.4.3`)
    + NOTE: GPU version is recommended for both PyTorch and DGL
    
## Installation
A conda environment is recommended. Below are the installation steps(For CUDA 10.2 Build). More details can be found on each item's official link. 
1. Set up [Python 3.7.x](https://www.python.org/downloads/)
2. Install [PyTorch](https://pytorch.org/)
3. Install [DGL](https://docs.dgl.ai/install/index.html)
4. Install other essential packages through `requirements.txt`

~~~shell script
$ conda create -n dnnperf python=3.7
$ conda activate dnnperf
$ conda install pytorch=1.5.0 torchvision cudatoolkit=10.2 -c pytorch
$ conda install -c dglteam dgl-cuda10.2=0.4.3
$ conda install --file requirements.txt
~~~

## Dataset and Pre-trained Model
We collect 18,641 model configurations. 
5 DL models (LeNet , ResNet-V1, Inception-V3, Vanilla RNN, and LSTM) plus the NAS(Neural Architecture Search) dataset constitutes the seen dataset (`Data/nas_hpo_seen`), which will be further split into train/validation/test set(7-1-2). 
The rest 5 DL models (AlexNet, VGG, OverFeat, ResNet-V2, and GRU) makes up the unseen set, which appears only in testset.

The dataset contains 2 files:
##### [**DL_model_runtime_perf_labels.csv**](docs/features_intro.md) which contains the real DL model runtime performance labels.

##### [**DL_model_runtime_perf_features.txt**](docs/features_intro.md)  which contains the real DL model computation graph(operators) features.

We place the DNNPerf pre-trained model (GNN_TIME and GNN_MEM) at folder ./models. To run the inference: 

```bash
python dnnperf.py --path=./Data/nas_hpo_seen/ --model_name="GNN_TIME" --type=time --load_previous=1 --epoch=0 --scale_up_labels=0.1 -hd=1024 --msg_rounds=3
python dnnperf.py --path=./Data/nas_hpo_seen/ --model_name="GNN_MEM" --type=mem --load_previous=1 --epoch=0 --scale_up_labels=1 -hd=2048 --msg_rounds=1
```

## Usage

To evaluate the training execution time prediction, we use the step:
~~~shell script
$ python dnnperf.py --path=./Data/nas_hpo_seen --epoch=200 --type=time --msg_rounds=3 -hd=1024 --scale_up_labels=0.1
~~~
To evaluate the GPU memory consumption prediction, we use the step:
~~~shell script
$ python dnnperf.py --path=./Data/nas_hpo_seen --epoch=250 --type=mem --msg_rounds=1 -hd=2048
~~~

Some args explanation:

+ -p, --path: dataset path
+ -s, --split: whether to split test set into subsets by model properties, e.g. split by edge count and node count
    + default is set to 1
+ -sul, --scale_up_labels: to scale up/down labels. use 0.1 for time and 1 for mem to align the two task's scale.
+ -tsr, --trainset_sampling_ratio: how much proportion of the original trainset will be used (For table 9) 
+ -mn, --model_name: whether to use default name for saving models
    + default is `None`
+ -mr, --msg_rounds: gnn message passing iterations
+ -efe, --edge_feature_enabled: switch for enabling ANEE, otherwise it will use GAT as our prediction model
    + ANEE is enabled by default
+ -a, --attention: attention mechanism. 
    + setting `--attention=0 --edge_feature_enabled=0` to enable GCN(BRP-NAS) baseline 
+ -ce, --concat_edge: if node feature and edge feature are concatenated after final message passing round
+ -avo, --avg_readout: avg each node's feature for final output, in comparison to summing up all features
+ -otf, --only_tensor_feature: if DNNPerf excludes cost feature, corresponding to our RQ3
+ -dt, --deterministic: if random seed is set(seed 21 is set by default).
+ -lp, --load_previous: if load_previous is on, DNNPerf can load models from model_name.
    + --model_name can be set to `None`(i.e. using default value) to use the default generated name or set the arg to use our custom model name.

Currently, DNNPerf front-end parser supported operator are listed at [supported_operator.md](docs/supported_operator.md)


## Experimental Scripts

[Evaluation scripts and results click here](./docs/evaluation_scripts.md)

### Simple demonstration

To evaluate the items of RQ2, using time prediction task as an example, we run following commands:
~~~shell script
$ python dnnperf.py --path=./Data/nas_hpo_seen/ --epoch=200 --type=time --edge_feature_enabled=0 --msg_rounds=3 --scale_up_labels=0.1 -hd=1024
$ python dnnperf.py --path=./Data/nas_hpo_seen/ --epoch=200 --type=time --only_tensor_feature=1 --msg_rounds=3 --scale_up_labels=0.1 -hd=1024
$ python dnnperf.py --path=./Data/nas_hpo_seen/ --epoch=200 --type=time --concat_edge=1 --msg_rounds=3 --scale_up_labels=0.1 -hd=1024
$ python dnnperf.py --path=./Data/nas_hpo_seen/ --epoch=200 --type=time --avg_readout=1 --msg_rounds=3 --scale_up_labels=0.1 -hd=1024
$ python dnnperf.py --path=./Data/nas_hpo_seen/ --epoch=200 --type=time --scaler="Standard" --msg_rounds=3 --scale_up_labels=0.1 -hd=1024
~~~
Our mixed test set is automatically split by setting `--split=1`, and the evaluation result can be observed by the terminal outputs.

### Output explanation:
Expected outputs(time) are listed as follows:
+ overall_unseen: all unseen hpo models
+ overall_seen: 20% of (nas + hpo seen models)
+ overall_seen_and_unseen: all models in testset (20% of the seen models + unseen models)
~~~
...
Testset: overall_unseen, length: 4406
TESTING
MSE: 3032.719230651855
ERR: 7.650940865278244
MAE: 36.5311598777771
RMSE: 55.07013011290108
Testset: overall_seen_and_unseen, length: 7253
TESTING
MSE: 3421.9280242919917
ERR: 7.4432916939258575
MAE: 33.14692497253418
RMSE: 58.49724800614121
~~~

### Experiments on PyTorch Dataset (RQ4)
Related scripts is under `scripts/mem_torch.sh` and `scripts/time_torch.sh`, and dataset corresponds to `Data/torch_hpo_data`.
These arguments should be enabled when running Pytorch test: `-bn=1 -ehif=1 -pt=1` (-batch_norm, -enhance_input_tensor_feature and pytorch_test)
To load previous trained models, run following commands
~~~shell script
$ python dnnperf.py --path=./Data/torch_hpo_data/ --epoch=0 --load_previous=1 --model_name=TORCH_MEM --type=mem --msg_rounds=2 --scale_up_labels=1 -hd=2048 -bn=1 -ehif=1 -pt=1
$ python dnnperf.py --path=./Data/torch_hpo_data/ --epoch=0 --load_previous=1 --model_name=TORCH_TIME --type=time --msg_rounds=2 --scale_up_labels=1000 -hd=1024 -bn=1 -ehif=1 -pt=1
~~~




