from data_utils.dataloader_utils import build_case_info_list, build_gnn_graph_list, min_max_normalize
import dgl
import torch


# main entry of dataset function
def get_gnn_exp_dataset(args):
    label_list, device_list, model_name_list = build_case_info_list(args.path, args.type, args.scale_up_labels)
    G_list, graph_dict_list, input_shape_list, _ = build_gnn_graph_list(args)

    dataset = list(
        zip(G_list, label_list, graph_dict_list, device_list, model_name_list))

    return list(dataset)

from sklearn.preprocessing import RobustScaler, MinMaxScaler, MaxAbsScaler, Normalizer, StandardScaler


def get_scaler_from_trainset(trainset: list, args):
    # dataset = list(zip(G_list, label_list, graph_dict_list, device_list, model_name_list))
    G_list, _, _, _, _ = zip(*trainset)
    G = dgl.batch(G_list)

    if args.scaler == "MinMax":
        e_transformer = MinMaxScaler()
        n_transformer = MinMaxScaler()
    elif args.scaler == "Robust":
        e_transformer = RobustScaler()
        n_transformer = RobustScaler()
    elif args.scaler == "MaxAbs":
        e_transformer = MaxAbsScaler()
        n_transformer = MaxAbsScaler()
    elif args.scaler == "Standard":
        e_transformer = StandardScaler()
        n_transformer = StandardScaler()
    elif args.scaler == "Normalizer":
        e_transformer = Normalizer()
        n_transformer = Normalizer()
    else:
        raise KeyError("scaler not implemented")


    n_transformer.fit(G.ndata["nfeat"].numpy())
    e_transformer.fit(G.edata["efeat"].numpy())

    return n_transformer, e_transformer


def scaler_transform_dataset(dataset, n_scaler, e_scaler):
    G_list, label_list, graph_dict_list, device_list, model_name_list = zip(
        *dataset)
    G = dgl.batch(G_list)

    G.ndata['nfeat'] = torch.Tensor(n_scaler.transform(G.ndata['nfeat'].numpy()))
    G.edata['efeat'] = torch.Tensor(e_scaler.transform(G.edata['efeat'].numpy()))

    G_list = dgl.unbatch(G)
    return list(zip(G_list, label_list, graph_dict_list, device_list, model_name_list))
