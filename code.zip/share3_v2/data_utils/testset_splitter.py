from data_utils.dataloader import get_gnn_exp_dataset, scaler_transform_dataset
from copy import deepcopy
import os


def split_test_set(original_testset, n_scaler, e_scaler, args=None):
    """
    Parameters
    ----------
    original_testset: mixed testset generated from original 20% of the whole dataset
    normalize_dict: min, max value of each dimension of feature
    args: args initialized in the main entry, used for further feature extension

    Returns: a dict of different testset
    -------

    """

    dataset_dict = {
        "node_cnt_20_30_list": [],
        "node_cnt_30_40_list": [],
        "node_cnt_40_50_list": [],
        "node_cnt_50_70_list": [],
        "edge_cnt_35_50_list": [],
        "edge_cnt_50_65_list": [],
        "edge_cnt_65_80_list": [],
        "edge_cnt_80_115_list": [],
        "overall_seen": deepcopy(original_testset),
        "overall_unseen": [],
        "overall_seen_and_unseen": deepcopy(original_testset),
    }
    # unseen models
    testset_models = [
        "overfeat",
        "alexnet",
        "resnet_v2",
        "vgg",
        "gru",
    ]

    subset_root_path = "./Data/"
    tmp_args = deepcopy(args)
    for testset_key in testset_models:
        try:
            print("Loading {}".format(testset_key))
            tmp_args.path = os.path.join(subset_root_path, testset_key)
            dataset_dict[testset_key + "(UNSEEN)"] = get_gnn_exp_dataset(tmp_args)
            dataset_dict["overall_unseen"].extend(deepcopy(dataset_dict[testset_key + "(UNSEEN)"]))
            dataset_dict["overall_seen_and_unseen"].extend(deepcopy(dataset_dict[testset_key + "(UNSEEN)"]))
        except:
            # print("{} get error!".format(testset_key))
            continue


    for item in original_testset:
        # each item is a tuple consisting of following sub-items
        # zip(G_list, label_list, graph_dict_list, device_list, model_name_list))
        if item[-1] not in dataset_dict:
            dataset_dict[item[-1]] = [deepcopy(item)]
        else:
            dataset_dict[item[-1]].append(deepcopy(item))

        if "nas" in item[-1]:
            # only split for nas data
            if 20 <= len(item[0]) < 30:
                dataset_dict["node_cnt_20_30_list"].append(deepcopy(item))
            elif 30 <= len(item[0]) < 40:
                dataset_dict["node_cnt_30_40_list"].append(deepcopy(item))
            elif 40 <= len(item[0]) < 50:
                dataset_dict["node_cnt_40_50_list"].append(deepcopy(item))
            elif 50 <= len(item[0]) < 70:
                dataset_dict["node_cnt_50_70_list"].append(deepcopy(item))

            if 35 <= len(item[0].edata['efeat']) < 50:
                dataset_dict["edge_cnt_35_50_list"].append(deepcopy(item))
            if 50 <= len(item[0].edata['efeat']) < 65:
                dataset_dict["edge_cnt_50_65_list"].append(deepcopy(item))
            if 65 <= len(item[0].edata['efeat']) < 80:
                dataset_dict["edge_cnt_65_80_list"].append(deepcopy(item))
            if 80 <= len(item[0].edata['efeat']) < 115:
                dataset_dict["edge_cnt_80_115_list"].append(deepcopy(item))


    # remove empty keys
    remove_list = []
    for key in dataset_dict:
        if len(dataset_dict[key]) == 0:
            remove_list.append(key)
    for key in remove_list:
        del dataset_dict[key]

    # normalize dataset
    for key in dataset_dict:
        print("Normalizing {}".format(key))
        dataset_dict[key] = scaler_transform_dataset(dataset_dict[key], n_scaler, e_scaler)
        # dataset_dict[key] = normalize_dataset(dataset_dict[key],
        #                                       normalize_dict)

    return dataset_dict
